# Name-Block plugin
Allows you to block names

# Command
Nameblock [command] [arg]


commands
 * reload - reloads blockednames
 * power - turn on/off the plugin
 * add - adds a name to the list
