# Installs the client

