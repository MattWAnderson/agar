# Unlocks locked files in src.
Solves issues with permissions

#### commands:

1. unlock (unlock files)

