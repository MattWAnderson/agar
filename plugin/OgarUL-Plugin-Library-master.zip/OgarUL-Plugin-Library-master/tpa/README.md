###### Simple Teleportations

##### Usage
> tpa [first player id] [second player id]
