# Devtools Plugin

Adds the dev command

dev command features

- hashfiles
- toggle devmode
- and create a files.json excluding files such as .txt or .log or anything that is not needed
