## Allows you to give minions to certain IPs.
Mabye you can turn it into a paid service


### Why?
Because we want to insult Moneyclip
