## Super Minions
Adds minions with superpowers


###Usage:

> superminion [playerid] [amount] [name] [spawnmass] [speed]
