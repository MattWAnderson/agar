### Minion Start
Gives people minions when they join
