###### Leaderboard FX
> Author : LegitSoulja

> Plugin : LeaderBoardFX

###### Includes
* Leaderboard Scrolling Text, of any given text.
* Leaderboard flash / strobe effect.
* Leaderboard Colors w/ color flash & changer.
* Leaderboard styles.

###### Moderation
> Things that help like, blocking words or replace or remove names. 
* Ability to remove name(s) as hidden, from Leaderboard.


###### Other plugin additions
* **Requested**: Lyrics of a song, and being displayed & playing, via soundcloud, or youtube. (David)


##### Any recommendations \/ comment on the last commit of this readme file :P
