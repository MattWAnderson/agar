# Leaderboard Stats plugin.

this  plugin displays stats on the leaderboard

##It also adds the customLB command to control this plugin.

customlb [command] [arg]

###COMMANDS

 Power - toggles the plugin
 Stats - toggles stats
 custom - Use this if you want to add your own thingsat the end of the leaderboard. Its custom then [duration] [msg1] [msg2] [msg...]


## The stats part goes trhough the faces for 6 seconds 
To activate, do `customlb stats`


face 1
~~~~~~Stats~~~~~~
Players:
Minions:
Bots:   Time:
[time]
~~~~~~~~~~~~~~~~~



Face 2
~~~~~~Stats~~~~~~~
Highscore:
By:
Oldhighscore:
~~~~~~~~~~~~~~~~~

