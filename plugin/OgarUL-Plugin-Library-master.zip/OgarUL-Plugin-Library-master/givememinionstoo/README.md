## GiveMeMinionsToo
Re writing of legitsouljas givememinions plugin

#### things done.
1. gmm command
2. configs
3. cleaned up code
