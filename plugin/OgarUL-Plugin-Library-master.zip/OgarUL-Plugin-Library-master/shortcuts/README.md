### Shortcuts plugin
When this plugin was created, we did not know that essentials commands was a thing that has shortened commands.
This plugin was ideal created by **DavidAli**, side assistance with **LegitSoulja**

### Shortcuts
**Commands**
- m     : short minion command replacement
- t     : short troll command replacement
- f     : short freeze command replacement
- ab    : short addbot command replacement
- kb    : short kickbots command replacement
- b    : short board command replacement
- rs    : short restart command replacement
- sp    : short spwanmass command replacement
- cb    : short chatban command replacement
- k    : short kill command replacement
- ka    : short killall command replacement
- ms    : short mass command replacement
- pl    : short playerlist   command replacement
- s     : short speed command replacement
- c     : short chat command replacement
- up    : short update command replacement
- kr    : short killrange command replacement
- p     : short pause command replacement
- mg    : short merge command replacement
