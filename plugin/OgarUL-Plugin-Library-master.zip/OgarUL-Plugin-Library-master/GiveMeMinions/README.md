# Give Me Minions
by legitsoulja

### Gives minions to a random person
