#Auth rewards plugin.
gives rewards to those who log in. requires auth plugin
