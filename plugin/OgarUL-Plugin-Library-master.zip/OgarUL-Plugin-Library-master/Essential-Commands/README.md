##Essential Commands
Adds commands and shortcuts


### Commands
1. tptoplayer [id] [targetid] tps you to a player
2. unkick [id] Unkicks a player so they dont have to reload

### Shortcuts
1. pl - playerlist
2. m - mass
3. s - speed
4. sm - spawnmass
5. e - explode
6. r - merge
7. t - troll

