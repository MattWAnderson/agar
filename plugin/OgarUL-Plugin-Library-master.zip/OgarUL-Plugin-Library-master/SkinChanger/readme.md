### Skin Changer!

**Commands**
- sc [add,rem] [id]
- sc reset

**Skin Changer Skin Usage**
 ```
 <sc>
 ```

### Custom Skins Usage
If you are using custom skins, set customSkins to 1 in the config. Skin Changer will now use your custom skins instead of premium default skins that all the other servers are using.

### Next update 1.0.1 
Live updated skins, (No default skin file), but customskins are still allowed.

> Plugin created by LegitSoulja


